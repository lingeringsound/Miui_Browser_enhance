## MIUI 浏览器增强

描述：恢复MIUI 浏览器的广告拦截功能，将会用到 **chattr** 命令防止恢复，请了解下 [chattr](https://www.cnbugs.com/post-3216.html)

## 
### 合并 **源** 

#### 如下，感谢各位大佬的规则！

| **名称** | **链接** |
| :-- | :-- |
| ***乘风*** | [link](https://cdn.jsdelivr.net/gh/xinggsf/Adblock-Plus-Rule@master/rule.txt) |
| ***360 rules*** | [link](https://code.gitlink.org.cn/api/v1/repos/keytoolazy/adblock/raw/Qihoo_Adblock_108) | 
| ***Adblock Plus EasylistChina*** | [link](https://easylist-downloads.adblockplus.org/easylistchina.txt) |
## 
## 工作原理

①替换[Host](https://cn.bing.com/search?q=%E4%BB%80%E4%B9%88%E6%98%AFHost)

②替换文件，MIUI浏览器的Adblock文件位于 ``/data/data/com.android.browser/files/data/adblock`` 而模块要做的就是复制然后加上 [chattr](https://www.cnbugs.com/post-3216.html) 锁定。

## 说明

> 模块目录( ``/data/adb/modules/MIUI_browser_key`` )下的 ``配置.prop`` 可以更换规则，更改完配置无需重启，直接执行模块目录下的service.sh。


- v2
 > ①解决部分误杀！
 > ②合并最新规则！
 > ③添加隐私追踪拦截！
 > ④优化脚本逻辑，实现更多可能！
- v3
 > 更新广告拦截规则
- v4
 > 取消合并MIUI 最新版的广告拦截规则，防止部分网站无法访问。(但是我好像没遇到过？)
- v5
 > ①修复部分bug
 > ②添加hosts 拦截MIUI 浏览器网址检测！
- v6
 > ①精简规则，减少卡顿
 > ②恢复合并MIUI 默认拦截规则
- v7
 > 修复脚本逻辑错误导致的拦截规则恢复
- v8
 > ①添加可选的广告拦截规则，例如 `AdFilters` `abpmerge` `adblockplus` `Adguard` `乘风` ，可在 **模块目录(压缩包)下 `配置.conf` 中修改。
 > ②更新隐私追踪拦截
- v9
 > ①添加 `anti-ad` 拦截
 > ②更新广告拦截规则
- v10
 > ①更新规则
 > ②删除部分误杀
- v11
 > 合并更新规则
- v12
 > ①更新规则
 > ②更正卸载脚本不执行的bug
 > ③更正脚本部分bug
- v13
 > ①更新规则
 > ②恢复MIUI 关键词联想，不想要的用户可以在 **模块的host** 里面取消注释。
- v14
 > 找到关键词联想不成功的原因了，是替换 `miui_privacylist` 的缘故，这里我就懒得找具体那条规则了，直接删掉一些规则。
- v15
 > MIUI浏览器更新了版本，有些规则已经无法生效。
 > 目前只能尝试更换新的规则。
- v18
 > 更新规则
- v20
 > 优化混合的性能，优化规则。
- v21
 > 加入adblock防检测规则
- v22
 > 强化了规则混合拦截能力，修复混合规则的一些误杀，提升了部分性能。
- v23
 > 更新广告拦截规则，尽力了，MIUI规则读取又出了一点问题。
- v24
 > ①防止部分误杀
 > ②修复神马/夸克搜索误杀
- v25
 > 小范围修复规则
- v26
 > 修复脚本bug
 > 增强了一些规则拦截
- v27
 > 更新规则
- v28
 > 修正部分误杀
- v30
 > 更新规则
- v31
 > 修复因 **MIUI隐私拦截(防追踪)** 能力增强而无法打开某些网页的问题。
- v32
 > 优化MIUI隐私拦截
- v35
 > 紧急修复上个版本混合规则的bug
- 43
 > 修复误杀
- 54
 > 添加Easylist规则
- 55
 > 修复部分误杀
- 59
 > 将默认规则替换为混合精简版
- 61
 > 更新规则，修复部分误杀。
- 62
 > 更新隐私保护和防误杀白名单。
- 67
 > 紧急修复一个bug
 > 还原MIUI白名单，MIUI浏览器新版本已经改成拦截？？？？傻逼MIUI，拦截了还叫白名单？
- v69
 > 添加在线更新
- v73
 > ①更新广告规则和MIUI隐私规则
 > ②如果感觉卡顿，请删除(修改后缀名) ``/data/user/0/com.android.browser/files/data/adblock/miui_privacylist.json`` ，MIUI隐私规则文件，以及模块内的 **Replace_privacy.sh** 脚本。
- v76
 > 更新百度部分规则
 > 删除MIUI占用日志 **zeuslogs** 文件夹
- v77
 > 禁用小米应用商店部分组件
- v78
 > 更新 **hosts** ，如果MIUI14出现问题，不再处理，自己删除模块内的/system文件夹。
- v79
- 欢度春节
> #### ***红梅含苞傲冬雪*** ***绿柳吐絮迎新春***
> #### 祝各位 ***万*** 事**顺心顺意**，***身*** 体**健康长寿**，***家*** 人**平安团聚**！
> ### **新年快乐**！
- v84
 > 更新 **MIUI隐私规则** ！优化访问速度！
- v85
 > #### 更新广告拦截规则。
 > #### 因 **个人原因** ，模块将 **停更** 一段时间。
- v86
 > ### 嗨嗨嗨，家人们，我又回来了！
- 97
 > ### 日常更新规则
 > ### 更新MIUI隐私规则，修复部分拦截错误，例如`阿里云`。
 > ### **更换更新链接为`Github`**
 > ### 但是碍于`Github`国内无法访问，所以换成了镜像链接(不稳定)
 > ### 所以还是推荐你们用 **蓝奏云链接**
 > ## [蓝奏云下载链接点击转跳](https://keytoolazy.lanzouw.com/b03j6gxra) **密码：666**
- 103
 > 更新规则，修复误杀。
 > ## [蓝奏云下载链接点击转跳](https://keytoolazy.lanzouw.com/b03j6gxra) **密码：666**
- 104
 > #### 更新规则，修复误杀。
- v108
 > #### 添加修改广告标记 `Marked Ads` 
 > #### 每天会连接网络，更新一次，不需要的时候，可以修改模块配置`/data/adb/modules/MIUI_browser_key/配置.prop` ，然后执行模块目录下的`service.sh`。
- v109
 > #### 修复广告标记的一些bug，允许保留原有的广告标记。
-- v114
 > ### **修复** v`113`版本百度和必应界面异常的问题。
- v118
 > 修复`混合规则精简版`无 ***domain*** 规则。
- v120
 > 修复部分网站播放视频黑屏问题。
 
