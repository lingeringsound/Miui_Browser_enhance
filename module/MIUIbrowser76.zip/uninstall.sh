#!/bin/sh

for dir in `ls -d /data/user/*/com.android.browser /data/data/com.android.browser 2>/dev/null `
do
	/data/adb/magisk/busybox chattr -R -i -a "${dir}" >/dev/null 2>&1
	busybox chattr -R -i -a "${dir}" >/dev/null 2>&1
	chattr -R -i -a "${dir}" >/dev/null 2>&1
done
