#!/bin/sh

function uninstall_module(){
for dir in `ls -d /data/user/*/com.android.browser /data/data/com.android.browser 2>/dev/null `
do
	/data/adb/magisk/busybox chattr -R -i -a "${dir}" >/dev/null 2>&1
	busybox chattr -R -i -a "${dir}" >/dev/null 2>&1
	chattr -R -i -a "${dir}" >/dev/null 2>&1
done

disable_list='
com.xiaomi.market/com.xiaomi.market.testsupport.DebugService
com.xiaomi.market/com.xiaomi.gamecenter.preload.PreloadService
com.xiaomi.market/com.xiaomi.downloader.service.DownloadService
com.xiaomi.market/com.xiaomi.market.reverse_ad.wakeup.ReverseAdWakeUpService
com.xiaomi.market/com.xiaomi.market.reverse_ad.service.ReverseAdScheduleService
com.xiaomi.market/com.xiaomi.market.reverse_ad.page.WebReverseAdActivity
com.xiaomi.market/com.xiaomi.market.business_ui.directmail.SourceFileDownloadAdsActivity
'

for target in ${disable_list} ;do
	pm enable "${target}" >/dev/null 2>&1
done
}

( uninstall_module &)

