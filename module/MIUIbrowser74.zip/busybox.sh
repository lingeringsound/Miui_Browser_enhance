busyboxdir=$MODPATH/busybox
magiskbusybox=/data/adb/magisk/busybox
test -e "$magiskbusybox" && {
chmod 0777 "$magiskbusybox"
mkdir -p "$busyboxdir"
echo "－ 安装Magisk的busybox 中……"
$magiskbusybox --install -s $busyboxdir && echo "－ 完成！" || abort "－ 错误！"
} || abort "－ 您的magisk busybox 怎么不见了？"
